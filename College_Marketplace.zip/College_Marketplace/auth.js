const mongoose=require('mongoose')

const productSchema=new mongoose.Schema({
    name:String,
    email:String,
    username:String,
    mobile:Number,
    password:Number
},{timestamps:true})

module.exports=mongoose.model('auth',authSchema);