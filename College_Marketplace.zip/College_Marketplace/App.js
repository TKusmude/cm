const express=require('express')
const App=express();
const model= require('./model')

const cors=require('cors');
App.use(cors());

App.use(express.json());

const mongoose=require('mongoose');
mongoose.connect('mongodb://localhost:27017/Market')

App.get(('/'),(req,res)=>
res.send('Server Connected.......!'))
 
App.post('/products', async(req , res)=>
{
    const{name,mobileNo,email,productName,price}=req.body;
    try{
        const users=new model({
            name,mobileNo,email,productName,price
        }
        );
        const data=await users.save()
        res.status(200).send({data})
    }
    catch
    {
        console.log(error)
    }
})

App.get(('/findall'),async(req,res)=>{
    try{
        const productData=await model.find();
        res.status(200).send({productData})
    }
    catch(error){
        console.log(error);
        res.status(500).send(error);
    }
})

const PORT=5000
App.listen(PORT,()=>{
    console.log(`app lisen on port ${PORT}`)
})